/* ============================================================
   Helper for turning the JWT credential that Google's Sign-In
   button hands back into a plain user object.

   We don't verify the token's signature here — that's fine
   because we never *trust* this token for anything sensitive;
   it's just used to populate the UI (name/email/photo) for a
   client-only bench console, same as the username/password
   gate in auth.js. If this app ever needs to protect a real
   backend, send the raw `credential` string to a server and
   verify it there with Google's public keys instead of reading
   it in the browser.
   ============================================================ */

/** Decode the payload of a JWT without checking its signature. */
function decodeJwtPayload(token) {
  const base64Url = token.split(".")[1];
  const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  const json = decodeURIComponent(
    atob(base64)
      .split("")
      .map((c) => "%" + c.charCodeAt(0).toString(16).padStart(2, "0"))
      .join("")
  );
  return JSON.parse(json);
}

/**
 * Turn the `credential` string from @react-oauth/google's GoogleLogin
 * onSuccess callback into the same shape auth.js's verify() returns,
 * so App.jsx doesn't need to care which sign-in method was used.
 */
export function userFromGoogleCredential(credential) {
  const payload = decodeJwtPayload(credential);
  return {
    username: payload.email,
    name: payload.name || payload.email,
    email: payload.email,
    picture: payload.picture,
    role: "operator",
    provider: "google"
  };
}
